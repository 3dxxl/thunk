export const DASISTEINEACTION = { 
	nameOffTheAction: () => {
		return {
			type: "DASISTEINEACTION",
		};
	}
	
	
}


export function THUNKDASISTEINEACTION(){ 
	return (dispatch, getState) => {

	
		console.log(getState());

		fetch('http://www.google.de', {

			mode:'no-cors'
		
		}).then(dispatch(DASISTEINEACTION))


	}
}


