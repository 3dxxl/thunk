import React, { Component } from 'react'

export class DritteSeite extends Component {
  render() {
    return (
      <div>
        Das ist die DritteSeite
      </div>
    )
  }
}

export default DritteSeite
